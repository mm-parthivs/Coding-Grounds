
/* Hide Header on on scroll down S */
// if ($(window).width() > 1199){
//   var didScroll;
//   var lastScrollTop = 0;
//   var delta = 15;
//   var navbarHeight = $('header').outerHeight();

//   $(window).scroll(function(event){
//       didScroll = true;
//       var scrollD = $(window).scrollTop();
//       if (scrollD >= 1) {
//           $('header').addClass('fixed');
//           // alert("o")
//       }
//       if (scrollD <= 1) {
//           $('header').removeClass('fixed');
//           // alert("os")
//       }
//   });

//   setInterval(function() {
//       if (didScroll) {
//           hasScrolled();
//           didScroll = false;
//       }
//   }, 250);
// }

// ===========================





$(document).ready(function(){
	$(".navbar-toggler").click(function(){
		$(this).hide();
		$("#navbarClose").show();
		$("body").addClass("show");
	});

	$("#navbarClose").click(function(){ // Assuming this is the close button for the navbar
		$(".navbar-toggler").show();
		$(this).hide();
		$("body").removeClass("show");
	});
	$(".nav-link").click(function(){ // Assuming this is the close button for the navbar
		$(".nav-menu").removeClass("show");
		$("body").removeClass("show");
		$(".navbar-toggler").show();
		$('#navbarClose').hide();
		
	});
});


//to get dynamic date in footer
document.getElementById("year").innerHTML = new Date().getFullYear();

// Fancybox Configuration
$('[data-fancybox="gallery"]').fancybox({
	buttons: [
		"thumbs",
		"fullScreen",
		"close"
	],
	loop: false,
	protect: true
});

// TOGGLE MENU
$("#navbarClose").hide();
$(".sidenavbar-brand").hide();

$("#navbarIcon").click(function () {
	// $("#navbarIcon").addClass("open");
	// $("#navbarMenu").addClass('show');
	$("body").addClass('menu-open');
	$(".sidenavbar-brand").show();
	$("#navbarIcon").hide();
	$("#navbarClose").show();
});

$("#navbarClose").click(function () {
	// $("#navbarIcon").addClass("open");
	// $("#navbarMenu").addClass('show');
	$(".navbar-collapse").removeClass('show');
	$("body").removeClass('menu-open');
	$(".sidenavbar-brand").hide();
	// $("#navbarIcon").addClass('navbar-toggler-icon');
	$("#navbarIcon").show();
	$("#navbarClose").hide();
});

// $(".nav-overlay").click(function(){
//   $("#navbarIcon").removeClass("open");
//   $("#navbarMenu").removeClass('show');
//   $("body").removeClass('menu-open');
// });

// $("#navbarIcon .menu-close-icon").click(function(){
//   $("#navbarIcon").removeClass("open");
//   $("#navbarMenu").removeClass('show');
//   $("body").removeClass('menu-open');
// });


var swiper = new Swiper(".banner_slider", {
	speed: 500,
	spaceBetween: 10,
	loop: true,
	pagination: {
		el: ".swiper-pagination",
	},
});


// $(document).ready(function () {
// 	$('#nav-aboutus').click(function() {
// 	$('html, body').animate({
// 	  scrollTop: $("#welcometochildplus").offset().top
// 	}, 100)
//   }), 
// 	$('div.middle').click(function (){
// 	  $('html, body').animate({
// 		scrollTop: $("div.bottom").offset().top
// 	  }, 1000)
// 	}),
// 	$('div.bottom').click(function (){
// 	  $('html, body').animate({
// 		scrollTop: $("div.top").offset(100).top
// 	  }, 1000)
// 	})
//   });